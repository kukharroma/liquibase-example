create function update_accounts_by_transaction(parent_transaction_id bigint) returns boolean
    language plpgsql
as
$$
BEGIN

      UPDATE accounts
         SET credits = credits + trx.trx_credits,
             coins = coins + trx.trx_coins
        FROM (
               SELECT SUM(credits) AS trx_credits,
                      SUM(coins) AS trx_coins,
                      account_id
                 FROM transactions
                WHERE parent_trx_id = parent_transaction_id
                GROUP BY account_id
             ) trx
       WHERE id = trx.account_id;

      UPDATE accounts
         SET credits = credits + trx.trx_credits,
             coins = coins + trx.trx_coins
        FROM (
               SELECT credits AS trx_credits,
                      coins AS trx_coins,
                      account_id
                 FROM transactions
                WHERE id = parent_transaction_id
             ) trx
       WHERE id = trx.account_id;

      DELETE FROM transactions
       WHERE parent_trx_id = parent_transaction_id;

      DELETE FROM transactions
       WHERE id = parent_transaction_id;

      RETURN TRUE;
    END;
$$;

alter function update_accounts_by_transaction(bigint) owner to postgres;

